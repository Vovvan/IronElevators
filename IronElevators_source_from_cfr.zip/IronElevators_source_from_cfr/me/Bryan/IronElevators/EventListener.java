/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerToggleSneakEvent
 */
package me.Bryan.IronElevators;

import me.Bryan.IronElevators.IronElevators;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

public class EventListener
implements Listener {
    IronElevators inst;

    public EventListener(IronElevators inst) {
        this.inst = inst;
    }

    @EventHandler
    public void downElevator(PlayerToggleSneakEvent e) {
        Player p = e.getPlayer();
        Block b = p.getLocation().getBlock().getRelative(BlockFace.DOWN);
        if (p.hasPermission("ironelevators.use") && !p.isSneaking() && b.getType() == this.inst.elevatorMaterial) {
            b = b.getRelative(BlockFace.DOWN, this.inst.minElevation);
            int i = this.inst.maxElevation;
            while (!(i <= 0 || b.getType() == this.inst.elevatorMaterial && b.getRelative(BlockFace.UP).getType().isTransparent() && b.getRelative(BlockFace.UP, 2).getType().isTransparent())) {
                --i;
                b = b.getRelative(BlockFace.DOWN);
            }
            if (i > 0) {
                Location l = p.getLocation();
                l.setY(l.getY() - (double)this.inst.maxElevation - 3.0 + (double)i);
                p.teleport(l);
                p.getWorld().playSound(l, this.inst.elevatorWhoosh, 1.0f, 0.0f);
            }
        }
    }

    @EventHandler
    public void upElevator(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Block b = e.getTo().getBlock().getRelative(BlockFace.DOWN);
        if (p.hasPermission("ironelevators.use") && e.getFrom().getY() < e.getTo().getY() && b.getType() == this.inst.elevatorMaterial) {
            b = b.getRelative(BlockFace.UP, this.inst.minElevation);
            int i = this.inst.maxElevation;
            while (!(i <= 0 || b.getType() == this.inst.elevatorMaterial && b.getRelative(BlockFace.UP).getType().isTransparent() && b.getRelative(BlockFace.UP, 2).getType().isTransparent())) {
                --i;
                b = b.getRelative(BlockFace.UP);
            }
            if (i > 0) {
                Location l = p.getLocation();
                l.setY(l.getY() + (double)this.inst.maxElevation + 3.0 - (double)i);
                p.teleport(l);
                p.getWorld().playSound(l, this.inst.elevatorWhoosh, 1.0f, 0.0f);
            }
        }
    }
}

