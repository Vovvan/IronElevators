/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.Sound
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.java.JavaPlugin
 */
package me.Bryan.IronElevators;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import me.Bryan.IronElevators.EventListener;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class IronElevators
extends JavaPlugin
implements Listener {
    public static final int FILE_COPY_MAX_BYTE_SIZE = 1024;
    public int maxElevation = 14;
    public int minElevation = 3;
    public Material elevatorMaterial = Material.IRON_BLOCK;
    public Sound elevatorWhoosh = Sound.ENTITY_IRONGOLEM_ATTACK;
    EventListener listener;
    FileConfiguration config;
    File configFile;

    public void onEnable() {
        this.loadConfig();
        this.getConfigValues();
        this.listener = new EventListener(this);
        this.getServer().getPluginManager().registerEvents((Listener)this.listener, (Plugin)this);
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
    }

    void getConfigValues() {
        this.maxElevation = this.config.getInt("maxElevation");
        this.minElevation = this.config.getInt("minElevation");
        this.elevatorMaterial = Material.valueOf((String)this.config.getString("elevatorMaterial"));
        this.elevatorWhoosh = Sound.valueOf((String)this.config.getString("elevatorWhoosh"));
    }

    void loadConfig() {
        try {
            this.config = new YamlConfiguration();
            this.configFile = new File(this.getDataFolder(), "config.yml");
            if (!this.configFile.exists()) {
                this.configFile.getParentFile().mkdirs();
                this.config.set("minElevation", (Object)this.minElevation);
                this.config.set("maxElevation", (Object)this.maxElevation);
                this.config.set("elevatorMaterial", (Object)this.elevatorMaterial.toString());
                this.config.set("elevatorWhoosh", (Object)this.elevatorWhoosh.toString());
                this.config.save(this.configFile);
            }
            this.config.load(this.configFile);
        }
        catch (Exception e) {
            Bukkit.getLogger().warning((Object)ChatColor.RED + "Exception " + Color.white + "when loading configuration file.\n" + e.getMessage());
        }
    }

    public static void copy(InputStream in, File file) {
        try {
            int len;
            FileOutputStream out = new FileOutputStream(file);
            byte[] buf = new byte[1024];
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.close();
            in.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

